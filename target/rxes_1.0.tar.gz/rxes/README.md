# XES Tools package

XES is the format used to store the event log <http://www.xes-standard.org>. 
Event logs are the basis for the process mining <http://www.processmining.org>. 
This extension to R allows you to work with XES logs:

* Get traces and events
* Calculate trace characteristics
* Analyze resource workload



